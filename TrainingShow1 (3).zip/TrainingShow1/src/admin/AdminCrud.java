package admin;

import java.util.List;



public interface AdminCrud {
	int insertAdmin(Admin admin);
	int updateAdmin(Admin admin);
	int deleteAdmin(int adminId);
	List<Admin> getAllAdmin();
	Admin getAdminById(int adminId);
	boolean checkCredential(int usid,String pswd1);

}
