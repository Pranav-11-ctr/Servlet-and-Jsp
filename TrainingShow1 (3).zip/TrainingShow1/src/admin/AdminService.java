package admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import user.UserConnection;
import user.UserLogin;



public class AdminService implements AdminCrud {
	public int insertAdmin(Admin admin) {
		int result=0;
		try
		{
			Connection con =AdminConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into admindetails(aid,aname,apswd) values(?,?,?)");
			ps.setInt(1, admin.getAdminId());
			ps.setString(2, admin.getName());
			ps.setString(3,admin.getPassword());
			
			result=ps.executeUpdate();
			con.close();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public int updateAdmin(Admin admin) {
		int result=0;
		try
		{
			Connection con=AdminConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("update admindetails set aid=?,aname=?,apswd=?");
			ps.setInt(1,admin.getAdminId());
			ps.setString(2,admin.getName());
			ps.setString(3,admin.getPassword());
			
			result=ps.executeUpdate();
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public int deleteAdmin(int adminId) {
		
		int result=0;
		try
		{
			Connection con=AdminConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from admindetails where aid=?");
			ps.setInt(1,adminId);
			result=ps.executeUpdate();
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public List<Admin> getAllAdmin() {
		ArrayList<Admin> list=new ArrayList<>();
		int result=0;
		try
		{
			Connection con=AdminConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet set=stmt.executeQuery("Select * from admindetails");
			
			while(set.next())
			{
				list.add(new Admin(set.getInt(1),set.getString(2),set.getString(3)));
				
			}
			stmt.close();
			con.close();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Admin getAdminById(int adminId) {
		Admin admin=null;
		try
		{
			Connection con=AdminConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("Select * from admindetails where aid=?");
			ps.setInt(1,adminId);
			ResultSet set=ps.executeQuery();
			if(set.next())
			{
				admin=new Admin(set.getInt(1),set.getString(2),set.getString(3));
			}
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return admin;
	}
	
	@Override
	public boolean checkCredential(int usid, String pswd1) {
		// TODO Auto-generated method stub
		ArrayList<UserLogin> list=new ArrayList<>();
		try {

			Connection con=UserConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet set=stmt.executeQuery("Select aid,apswd from admindetails");
			while(set.next())
			{
				list.add(new UserLogin(set.getInt(1),set.getString(2)));
			}
			con.close();
			for(int i=0;i<list.size();i++)
			{
				if(list.get(i).getUserId()==usid)
				{
					if(list.get(i).getPassword().equals(pswd1))
					{
						return true;
					}
				}
			}
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return false;
	}

}
