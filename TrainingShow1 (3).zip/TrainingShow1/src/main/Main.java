package main;

import java.util.List;
import java.util.Scanner;

import user.UserLogin;
import user.UserController;
import user.User;
import admin.Admin;
import admin.AdminController;
import city.City;
import city.CityController;
import newCityClassify.ncc;
import newCityClassify.nccController;
import CityClassify.CityClassified;
import CityClassify.CityClassifyController;

public class Main {
	public static void main(String[] args) {
		int optio;
		int ch;
		int role;
		int usid;
		int select;
		int cid;
        String name1;
		int adminId;
		String pswd1;
		String name;
		String password;
		Admin admin = null;
		int result;
		boolean b;
		AdminController adctrl = new AdminController();

		int userId;
		String userName;
		UserController userCtrl = new UserController();
		;
		User user = null;

		CityController cityctrl = new CityController();
		int id;
		String cityname;
		String inst;
		String inst_det;
		int choice;
		City city = null;

		String cno;
		String desc;
		//CityClassified cca = null;
		ncc cca=null;
		//CityClassifyController ccc = new CityClassifyController();
		nccController ccc=new nccController();

		while (true) {
			System.out.println("1. Log in as a USER ");
			System.out.println("2. Log in as ADMIN ");
			System.out.println("3. Insert as a new User");
			//System.out.println("4. Forgot password user");
			System.out.println("4. To exit");
			System.out.println("Choose the Role");
//			System.out.println("1. ADMIN ");
//			System.out.println("2. USER ");
			Scanner sc = new Scanner(System.in);
			role = sc.nextInt();
			if (role == 1) {
				System.out.println("Enter your userId");
				usid = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter password");
				pswd1 = sc.nextLine();
				b = userCtrl.checkCredential(usid, pswd1);
				// System.out.println(b);
				if (b) {
					while (true) {

						System.out.println("\n*****  Welcome as a user *****\n ");
						//System.out.println("0. To exit");
						System.out.println("1. Insert CityClassify");
//						System.out.println("2. Update CityClassify");
//						System.out.println("3. Delete CityClassify");
//						System.out.println("4. View CityClassify");
//						System.out.println("5. View a CityClassify");
						System.out.println("2 Enter city name to know what are the institution in that city");
						System.out.println("3 Show City");
						System.out.println("4 Update City Classify which is posted by user itself");
						System.out.println("5 Delete City Classify which is posted by user itself");
						System.out.println("6 Show City by gving institute type");
						System.out.println("Enter 0 to exit");
						System.out.println("Enter your choice");
						ch = sc.nextInt();

						switch (ch) {
						case 1:
							System.out.println("Enter Id, contact_no , description");
							id = sc.nextInt();
							sc.nextLine();
							cno = sc.nextLine();
							desc = sc.nextLine();
							cca = new ncc(id,usid, cno, desc);
							result = ccc.insertCityClassifyUser(cca);
							if (result > 0) {
								System.out.println("CityClassify inserted");
							} else {
								System.out.println("CityClassify not inserted");
							}

							break;

						
						case 2:
							sc.nextLine();
							System.out.println("Enter the city name");
							String nameC = sc.nextLine();
							List<ncc> list1 = userCtrl.getInstitutionByName(nameC);
							for (ncc cty : list1) {
								System.out.println(cty.getId() + "\t" + cty.getContdet() + "\t" + cty.getDescdetl());
							}
							break;
						case 3:
							System.out.println("Cities which are in list");
							List<City> list11 = userCtrl.getCities();
							for (City cty : list11) {
								System.out.println(cty.getId()+"\t"+cty.getCityname());
							}
							break;
						case 4:
							System.out.println("Your city classified posts are");
							List<ncc> list3=ccc.getCityClassifyByUserId(usid);
							for(ncc n1:list3)
							{
								System.out.println(n1.getId()+"\t"+n1.getContdet()+"\t"+n1.getDescdetl());
							}
							System.out.println("Enter City id which which you want to update");
							cid=sc.nextInt();
							for(int i=0;i<list3.size();i++)
							{
								if(cid==list3.get(i).getId())
								{
									System.out.println("Enter contact no, description ");
									sc.nextLine();
									cno=sc.nextLine();
									desc=sc.nextLine();
									cca=new ncc(cid,usid,cno,desc);
									result=ccc.updateCityClassify(cca);
									if(result>0)
									{
										System.out.println("Updated");
									}
									else
									{
										System.out.println("Not updated");
									}
									break;
								}
								else
								{
									System.out.println("Wrong Credential");
								}
							}
							break;
						case 5:
							System.out.println("Your city classified posts are");
							List<ncc> list5=ccc.getCityClassifyByUserId(usid);
							for(ncc n2:list5)
								System.out.println(n2.getId()+"\t"+n2.getContdet()+"\t"+n2.getDescdetl());
							System.out.println("Enter City id which which you want to delete");
							cid=sc.nextInt();
							for(int i=0;i<list5.size();i++)
							{
								if(cid==list5.get(i).getId())
								{
									
									result=ccc.deleteCityClassify(cid);
									if(result>0)
									{
										System.out.println("Deleted");
									}
									else
									{
										System.out.println("Not Deleted");
									}
									break;
								}
								else
								{
									System.out.println("Wrong Credential");
								}
							}
							break;
						case 6:
							System.out.println("Institute types in list are:-");
							List<String> list19=cityctrl.instituteType();
							for(String name11:list19)
							{
								System.out.println(name11);
							}
							sc.nextLine();
							System.out.println("Enter institute type");
							name1=sc.nextLine();
							List<City> list20=cityctrl.getCityByInstitudeName(name1);
							for(City name11:list20)
							{
								System.out.println(name11.getCityname()+"\t"+name11.getInst_det());
							}
							break;
						case 0:
							System.exit(0);
							break;
						}
					}

				} else {
					System.out.println("You are giving wrong credential");
				}
			} else if (role == 2) {
				System.out.println("Enter your Admin Id");
				usid = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter password");
				pswd1 = sc.nextLine();
				b = adctrl.checkCredential(usid, pswd1);
				// System.out.println(b);
				if (b) {
					while (true) {
						System.out.println("1. User Operation");
						System.out.println("2. CITY DATA operation");
						System.out.println("3. CITYCLASSIFIED DATA operation");
						System.out.println("Enter 0 to exit");
						System.out.println("Enter your choice");
						select = sc.nextInt();
						if (select == 1) {
							//System.out.println("1 Insert User");
							System.out.println("2 Update User");
							System.out.println("3 Delete User");
							System.out.println("4 View User");
							System.out.println("5 View a User");
							System.out.println("6 Enter city name to know what are the institution in that city");
							System.out.println("7 Show City");
							System.out.println("Enter 0 to exit");
							sc = new Scanner(System.in);
							System.out.println("Enter your choice");
							ch = sc.nextInt();
							switch (ch) {
							case 0:
								System.exit(0);
								break;
							case 1:
								System.out.println("Enter UserId , Username , password");
								userId = sc.nextInt();
								sc.nextLine();
								userName = sc.nextLine();
								password = sc.nextLine();
								user = new User(userId, userName, password);
								result = userCtrl.insertUser(user);
								if (result > 0) {
									System.out.println("User inserted");
								} else {
									System.out.println("User Not insertd");
								}
								break;
							case 2:
								System.out.println("Enter UserId , Username , password");
								userId = sc.nextInt();
								sc.nextLine();
								userName = sc.nextLine();
								password = sc.nextLine();
								user = new User(userId, userName, password);
								result = userCtrl.updateUser(user);
								if (result > 0) {
									System.out.println("User Updated");
								} else {
									System.out.println("User Not Updated");
								}
								break;
							case 3:
								System.out.println("Enter UserId");
								userId = sc.nextInt();
								result=ccc.deleteCityByUserId(userId);
								result = userCtrl.deleteUser(userId);
								int res=ccc.deleteCityByUserId(userId);
								if (result > 0) {
									System.out.println("User deleted");
								} else {
									System.out.println("User not deleted");
								}
								break;
							case 4:
								List<User> list = userCtrl.getAllUser();
								for (User usr : list) {
									System.out
											.println(usr.getUserId() + "\t" + usr.getName() + "\t" + usr.getPassword());
								}
								break;
							case 5:
								System.out.println("Enter UserId");
								userId = sc.nextInt();
								user = userCtrl.getUserById(userId);
								System.out.println("UserId " + user.getUserId());
								System.out.println("Username " + user.getName());
								System.out.println("Password " + user.getPassword());
								break;

							case 6:
								sc.nextLine();
								System.out.println("Enter the city name");
								String nameC = sc.nextLine();
								List<ncc> list1 = userCtrl.getInstitutionByName(nameC);
								for (ncc cty : list1) {
									System.out.println(cty.getId() + "\t" + cty.getContdet() + "\t" + cty.getDescdetl());
								}
								break;
							case 7:
								System.out.println("Cities which are in list");
								List<String> list2 = userCtrl.getallCities();
								for (String cty : list2) {
									System.out.println(cty);
								}
								break;
							}
						} else if (select == 2) {
							System.out.println("1. Add City ");
							System.out.println("2. Update City");
							System.out.println("3. Delete City");
							System.out.println("4. View Cities");
							System.out.println("5. View a City");
							System.out.println("0. Exit ");
							System.out.println("Enter your choice");
							choice = sc.nextInt();

							switch (choice) {
							case 1:
								System.out.println("Enter id, cityname, institute Name,institute_details");
								id = sc.nextInt();
								sc.nextLine();
								cityname = sc.nextLine();
								inst = sc.nextLine();
								inst_det = sc.nextLine();
								city = new City(id, cityname, inst, inst_det);
								result = cityctrl.insertRecord(city);
								if (result > 0)
									System.out.println("Record Inserted");
								else
									System.out.println("Record not inserted");
								break;

							case 2:
								System.out.println("Enter id, cityname, institute Name,institute_details");
								id = sc.nextInt();
								sc.nextLine();
								cityname = sc.nextLine();
								inst = sc.nextLine();
								inst_det = sc.nextLine();
								city = new City(id, cityname, inst, inst_det);
								result = cityctrl.updateRecord(city);
								if (result > 0)
									System.out.println("Record updated");
								else
									System.out.println("Record not found");
								break;

							case 3:
								System.out.println("Enter id");
								id = sc.nextInt();
								result = cityctrl.deleteRecord(id);
								if (result > 0)
									System.out.println("Record deleted");
								else
									System.out.println("Record not found");
								break;

							case 4:
								List<City> list = cityctrl.getAllRecords();
								for (City cit : list) {
									System.out.println(cit.getId() + "\t" + cit.getCityname() + " \t " + cit.getInst()+ "\t" + cit.getInst_det());
								}
								break;

							case 5:
								System.out.println("Enter id");
								id = sc.nextInt();
								city = cityctrl.getCityById(id);
								System.out.println("Id = " + city.getId());
								System.out.println("Cityname = " + city.getCityname());
								System.out.println("Institute name = " + city.getInst());
								System.out.println("Institute details = " + city.getInst_det());
								break;

							case 0:
								System.exit(0);
							}
						} else if (select == 3) {
							System.out.println("1. Insert CityClassify");
							System.out.println("2. Update CityClassify");
							System.out.println("3. Delete CityClassify");
							System.out.println("4. View CityClassify");
							System.out.println("5. View a CityClassify");
							System.out.println("6. Show Cities by giving institute type");
							System.out.println("Enter 0 to exit");
							System.out.println("Enter your choice");
							ch = sc.nextInt();

							switch (ch) {
							case 1:
								System.out.println("Enter Id, contact_no , description");
								id = sc.nextInt();
								sc.nextLine();
								cno = sc.nextLine();
								desc = sc.nextLine();
								cca = new ncc(id,usid, cno, desc);
								result = ccc.insertCityClassifyUser(cca);
								if (result > 0) {
									System.out.println("CityClassify inserted");
								} else {
									System.out.println("CityClassify not inserted");
								}

								break;

							case 2:
								System.out.println("Your city classified posts are");
								System.out.println("Which you want to update\n1.  Yourself\n2.  User");
								optio=sc.nextInt();
								
								if(optio==1)
								{ 
									System.out.println("Your posts are");
									List<ncc> list3=ccc.getCityClassifyByUserId(usid);
									for(ncc n1:list3)
									{
										System.out.println(n1.getId()+"\t"+n1.getContdet()+"\t"+n1.getDescdetl());
									}
									System.out.println("Enter City id which which you want to update");
									cid=sc.nextInt();
									for(int i=0;i<list3.size();i++)
									{
										if(cid==list3.get(i).getId())
										{
											System.out.println("Enter contact no, description ");
											sc.nextLine();
											cno=sc.nextLine();
											desc=sc.nextLine();
											cca=new ncc(cid,usid,cno,desc);
											result=ccc.updateCityClassify(cca);
											if(result>0)
											{
												System.out.println("Updated");
											}
											else
											{
												System.out.println("Not updated");
											}
											break;
										}
										else
										{
											System.out.println("Wrong Credential");
										}
									}
								}else if(optio==2)
								{
									System.out.println("User posts are");
									List<ncc> list3=ccc.getCityClassifyUsers(usid);
									for(ncc n1:list3)
									{
										System.out.println(n1.getId()+"\t"+n1.getContdet()+"\t"+n1.getDescdetl());
									}
									System.out.println("Enter City id which which you want to update");
									cid=sc.nextInt();
									for(int i=0;i<list3.size();i++)
									{
										if(cid==list3.get(i).getId())
										{
											System.out.println("Enter contact no, description ");
											sc.nextLine();
											cno=sc.nextLine();
											desc=sc.nextLine();
											cca=new ncc(cid,usid,cno,desc);
											result=ccc.updateCityClassify(cca);
											if(result>0)
											{
												System.out.println("Updated");
											}
											else
											{
												System.out.println("Not updated");
											}
											break;
										}
										else
										{
											System.out.println("Wrong Credential");
										}
									}
								}
//								System.out.println("User City classify posts Are:");
//								List<ncc> list6=ccc.getAllCityClassify();
//								for(ncc n1:list6)
//								{
//									System.out.println(n1.getId()+"\t"+n1.getContdet()+"\t"+n1.getDescdetl());
//								}
//								
//								
//								cid=sc.nextInt();
//								for(int i=0;i<list3.size();i++)
//								{
//									if(cid==list3.get(i).getId())
//									{
//										System.out.println("Enter contact no, description ");
//										sc.nextLine();
//										cno=sc.nextLine();
//										desc=sc.nextLine();
//										cca=new ncc(cid,usid,cno,desc);
//										result=ccc.updateCityClassify(cca);
//										if(result>0)
//										{
//											System.out.println("Updated");
//										}
//										else
//										{
//											System.out.println("Not updated");
//										}
//										break;
//									}
//									else
//									{
//										System.out.println("Wrong Credential");
//									}
//								}
								break;
							case 3:
//								System.out.println("Your city classified posts are");
								System.out.println("Which you want to Delete\n1.  Yourself\n2.  User");
								optio=sc.nextInt();
								
								if(optio==1)
								{ 
									System.out.println("Your posts are");
									List<ncc> list3=ccc.getCityClassifyByUserId(usid);
									for(ncc n1:list3)
									{
										System.out.println(n1.getId()+"\t"+n1.getContdet()+"\t"+n1.getDescdetl());
									}
									System.out.println("Enter City id which which you want to Delete");
									cid=sc.nextInt();
									for(int i=0;i<list3.size();i++)
									{
										if(cid==list3.get(i).getId())
										{
//											System.out.println("Enter contact no, description ");
//											sc.nextLine();
//											cno=sc.nextLine();
//											desc=sc.nextLine();
//											cca=new ncc(cid,usid,cno,desc);
											result=ccc.deleteCityClassify(cid);
											if(result>0)
											{
												System.out.println("Deleted");
											}
											else
											{
												System.out.println("Not Deleted");
											}
											break;
										}
										else
										{
											System.out.println("Wrong Credential");
										}
									}
								}else if(optio==2)
								{
									System.out.println("User posts are");
									List<ncc> list3=ccc.getCityClassifyUsers(usid);
									for(ncc n1:list3)
									{
										System.out.println(n1.getId()+"\t"+n1.getContdet()+"\t"+n1.getDescdetl());
									}
									System.out.println("Enter City id which which you want to Delete");
									cid=sc.nextInt();
									for(int i=0;i<list3.size();i++)
									{
										if(cid==list3.get(i).getId())
										{
//											System.out.println("Enter contact no, description ");
//											sc.nextLine();
//											cno=sc.nextLine();
//											desc=sc.nextLine();
//											cca=new ncc(cid,usid,cno,desc);
											result=ccc.deleteCityClassify(cid);;
											if(result>0)
											{
												System.out.println("Deleted");
											}
											else
											{
												System.out.println("Not Deleted");
											}
											break;
										}
										else
										{
											System.out.println("Wrong Credential");
										}
									}
								}
								
								
								
								
								
								
								
//								System.out.println("Your city Classified posts are");
//								List<ncc> list2=ccc.getCityClassifyByUserId(usid);
//								System.out.println("Enter City id which which you want to delete");
//								cid=sc.nextInt();
//								for(ncc n1:list2)
//								{
//									System.out.println(n1.getId()+"\t"+n1.getContdet()+"\t"+n1.getDescdetl());
//								}
//								System.out.println("User City classify posts Are:");
//								List<ncc> list7=ccc.getAllCityClassify();
//								for(ncc n1:list7)
//								{
//									System.out.println(n1.getId()+"\t"+n1.getContdet()+"\t"+n1.getDescdetl());
//								}
//								for(int i=0;i<list2.size();i++)
//								{
//									if(cid==list2.get(i).getId())
//									{
//										
//										result=ccc.deleteCityClassify(cid);
//										if(result>0)
//										{
//											System.out.println("Deleted");
//										}
//										else
//										{
//											System.out.println("Not Deleted");
//										}
//										break;
//									}
//									else
//									{
//										System.out.println("Wrong Credential");
//									}
//								}
								break;
							case 4:
								List<ncc> list = ccc.getAllCityClassify();
								for (ncc admn : list) {
									System.out.println("CityClassify Id : " + admn.getId()
											+ "\n CityClassify Contact number : " + admn.getContdet()
											+ "\n CityClassify description : " + admn.getDescdetl());
								}

								break;
							case 5:

								System.out.println("Enter CityClassify Id");
								id = sc.nextInt();
								cca = ccc.getCityClassifyByCityId(id);
								System.out.println("CityClassify Id : " + cca.getId() + "\nCityClassify Contact : "
										+ cca.getContdet() + "\nCityClassify description : " + cca.getDescdetl());
								break;
							case 6:
								System.out.println("Institute types in list are:-");
								List<String> list19=cityctrl.instituteType();
								for(String name11:list19)
								{
									System.out.println(name11);
								}
								sc.nextLine();
								System.out.println("Enter institute type");
								name1=sc.nextLine();
								List<City> list20=cityctrl.getCityByInstitudeName(name1);
								for(City name11:list20)
								{
									System.out.println(name11.getCityname()+"\t"+name11.getInst_det());
								}
								break;
							case 0:
								System.exit(0);
								break;
							}
						} else if (select == 4) {
							System.exit(0);
						}
					}
				}

				else {
					System.out.println("You are giving wrong credential");
				}
			} else if (role == 3) {
				System.out.println("Insert User data");
				System.out.println("Enter UserId , Username , password");
				userId = sc.nextInt();
				sc.nextLine();
				userName = sc.nextLine();
				password = sc.nextLine();
				user = new User(userId, userName, password);
				result = userCtrl.insertUser(user);
				if (result > 0) {
					System.out.println("User inserted");
				} else {
					System.out.println("User Not insertd");
				}
			} else if (role == 4) {
				System.exit(0);
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	

//				} else if (role == 3) {
//					System.out.println("1. Insert CityClassify");
//					System.out.println("2. Update CityClassify");
//					System.out.println("3. Delete CityClassify");
//					System.out.println("4. View CityClassify");
//					System.out.println("5. View a CityClassify");
//					System.out.println("Enter 0 to exit");
//					System.out.println("Enter your choice");
//					ch = sc.nextInt();
//
//					switch (ch) {
//					case 1:
//						System.out.println("Enter Id, contact_no , description");
//						id = sc.nextInt();
//						sc.nextLine();
//						cno = sc.nextLine();
//						desc = sc.nextLine();
//						cca = new CityClassified(id, cno, desc);
//						result = ccc.insertCityClassify(cca);
//						if (result > 0) {
//							System.out.println("CityClassify inserted");
//						} else {
//							System.out.println("CityClassify not inserted");
//						}
//
//						break;
//
//					case 2:
//						System.out.println("Enter Id, contact_no , description");
//						id = sc.nextInt();
//						sc.nextLine();
//						cno = sc.nextLine();
//						desc = sc.nextLine();
//						cca = new CityClassified(id, cno, desc);
//						result = ccc.updateCityClassify(cca);
//						if (result > 0) {
//							System.out.println("CityClassify updated");
//						} else {
//							System.out.println("CityClassify not updated");
//						}
//						break;
//					case 3:
//						System.out.println("Enter CityClassifyid");
//						id = sc.nextInt();
//						result = ccc.deleteCityClassify(id);
//						if (result > 0) {
//							System.out.println("CityClassify Deleted");
//						} else {
//							System.out.println("CityClassify not deleted");
//						}
//
//						break;
//					case 4:
//						List<CityClassified> list = ccc.getAllCityClassify();
//						for (CityClassified admn : list) {
//							System.out.println("CityClassify Id : " + admn.getId() + "\n CityClassify Contact number : "
//									+ admn.getContdet() + "\n CityClassify description : " + admn.getDescdetl());
//						}
//
//						break;
//					case 5:
//
//						System.out.println("Enter CityClassify Id");
//						id = sc.nextInt();
//						cca = ccc.getAdminById(id);
//						System.out.println("CityClassify Id : " + cca.getId() + "\nCityClassify Contact : "
//								+ cca.getContdet() + "\nCityClassify description : " + cca.getDescdetl());
//						break;
//					case 0:
//						System.exit(0);
//						break;
//					}
//				}
//
//			}
//
//			if (role == 1) {
//				System.out.println("1. ADMIN DATA");
//				System.out.println("2. CITY DATA");
//				System.out.println("3. CITYCLASSIFIED DATA");
//				System.out.println("Enter your choice");
//				select = sc.nextInt();
//				if (select == 1) {
//					System.out.println("1. Insert Admin");
////					System.out.println("2. Update Admin");
////					System.out.println("3. Delete Admin");
//					System.out.println("4. View Admin");
//					System.out.println("5. View a admin");
//					System.out.println("Enter 0 to exit");
//
//					System.out.println("Enter your choice");
//					ch = sc.nextInt();
//
//					switch (ch) {
//					case 1:
//						System.out.println("Enter AdminId, AdminName , password");
//						adminId = sc.nextInt();
//						sc.nextLine();
//						name = sc.nextLine();
//						password = sc.nextLine();
//						admin = new Admin(adminId, name, password);
//						result = adctrl.insertAdmin(admin);
//						if (result > 0) {
//							System.out.println("Admin inserted");
//						} else {
//							System.out.println("Admin not inserted");
//						}
//
//						break;
//
//					case 2:
//
//						System.out.println("Enter AdminId, AdminName , password");
//						adminId = sc.nextInt();
//						sc.nextLine();
//						name = sc.nextLine();
//						password = sc.nextLine();
//						admin = new Admin(adminId, name, password);
//						result = adctrl.updateAdmin(admin);
//						if (result > 0) {
//							System.out.println("Admin updated");
//						} else {
//							System.out.println("Admin not updated");
//						}
//
//						break;
//					case 3:
//						System.out.println("Enter adminid");
//						adminId = sc.nextInt();
//						result = adctrl.deleteAdmin(adminId);
//						if (result > 0) {
//							System.out.println("Admin Deleted");
//						} else {
//							System.out.println("Admin not deleted");
//						}
//
//						break;
//					case 4:
//						List<Admin> list = adctrl.getAllAdmin();
//						for (Admin admn : list) {
//							System.out.println("Admin Id : " + admn.getAdminId() + "\n Admin Name : " + admn.getName()
//									+ "\n Admin Password : " + admn.getPassword());
//						}
//
//						break;
//					case 5:
//
//						System.out.println("Enter Admin Id");
//						adminId = sc.nextInt();
//						admin = adctrl.getAdminById(adminId);
//						System.out.println("Admin Id : " + admin.getAdminId() + "\nAdmin Name : " + admin.getName()
//								+ "\nAdmin Password : " + admin.getPassword());
//						break;
//					case 0:
//						System.exit(0);
//						break;
//					}
//				} else if (select == 2) {
//					System.out.println("1. Add City ");
//					System.out.println("2. Update City");
//					System.out.println("3. Delete City");
//					System.out.println("4. View Cities");
//					System.out.println("5. View a City");
//					System.out.println("0. Exit ");
//					System.out.println("Enter your choice");
//					choice = sc.nextInt();
//
//					switch (choice) {
//					case 1:
//						System.out.println("Enter id, cityname, institute Name,institute_details");
//						id = sc.nextInt();
//						sc.nextLine();
//						cityname = sc.nextLine();
//						inst = sc.nextLine();
//						inst_det = sc.nextLine();
//						city = new City(id, cityname, inst, inst_det);
//						result = cityctrl.insertRecord(city);
//						if (result > 0)
//							System.out.println("Record Inserted");
//						else
//							System.out.println("Record not inserted");
//						break;
//
//					case 2:
//						System.out.println("Enter id, cityname, institute Name,institute_details");
//						id = sc.nextInt();
//						sc.nextLine();
//						cityname = sc.nextLine();
//						inst = sc.nextLine();
//						inst_det = sc.nextLine();
//						city = new City(id, cityname, inst, inst_det);
//						result = cityctrl.updateRecord(city);
//						if (result > 0)
//							System.out.println("Record updated");
//						else
//							System.out.println("Record not found");
//						break;
//
//					case 3:
//						System.out.println("Enter id");
//						id = sc.nextInt();
//						result = cityctrl.deleteRecord(id);
//						if (result > 0)
//							System.out.println("Record deleted");
//						else
//							System.out.println("Record not found");
//						break;
//
//					case 4:
//						List<City> list = cityctrl.getAllRecords();
//						for (City cit : list) {
//							System.out.println(cit.getId() + "\t" + cit.getCityname() + " \t " + cit.getInst() + "\t"
//									+ cit.getInst_det());
//						}
//						break;
//
//					case 5:
//						System.out.println("Enter id");
//						id = sc.nextInt();
//						city = cityctrl.getCityById(id);
//						System.out.println("Id = " + city.getId());
//						System.out.println("Cityname = " + city.getCityname());
//						System.out.println("Institute name = " + city.getInst());
//						System.out.println("Institute details = " + city.getInst_det());
//						break;
//
//					case 0:
//						System.exit(0);
//					}
//				} else if (select == 3) {
//					System.out.println("1. Insert CityClassify");
//					System.out.println("2. Update CityClassify");
//					System.out.println("3. Delete CityClassify");
//					System.out.println("4. View CityClassify");
//					System.out.println("5. View a CityClassify");
//					System.out.println("Enter 0 to exit");
//					// Scanner sc = new Scanner(System.in);
//					System.out.println("Enter your choice");
//					ch = sc.nextInt();
//
//					switch (ch) {
//					case 1:
//						System.out.println("Enter Id, contact_no , description");
//						id = sc.nextInt();
//						sc.nextLine();
//						cno = sc.nextLine();
//						desc = sc.nextLine();
//						cca = new CityClassified(id, cno, desc);
//						result = ccc.insertCityClassify(cca);
//						if (result > 0) {
//							System.out.println("CityClassify inserted");
//						} else {
//							System.out.println("CityClassify not inserted");
//						}
//
//						break;
//
//					case 2:
//						System.out.println("Enter Id, contact_no , description");
//						id = sc.nextInt();
//						sc.nextLine();
//						cno = sc.nextLine();
//						desc = sc.nextLine();
//						cca = new CityClassified(id, cno, desc);
//						result = ccc.updateCityClassify(cca);
//						if (result > 0) {
//							System.out.println("CityClassify updated");
//						} else {
//							System.out.println("CityClassify not updated");
//						}
//						break;
//					case 3:
//						System.out.println("Enter CityClassifyid");
//						id = sc.nextInt();
//						result = ccc.deleteCityClassify(id);
//						if (result > 0) {
//							System.out.println("CityClassify Deleted");
//						} else {
//							System.out.println("CityClassify not deleted");
//						}
//
//						break;
//					case 4:
//						List<CityClassified> list = ccc.getAllCityClassify();
//						for (CityClassified admn : list) {
//							System.out.println("CityClassify Id : " + admn.getId() + "\n CityClassify Contact number : "
//									+ admn.getContdet() + "\n CityClassify description : " + admn.getDescdetl());
//						}
//
//						break;
//					case 5:
//
//						System.out.println("Enter CityClassify Id");
//						id = sc.nextInt();
//						cca = ccc.getAdminById(id);
//						System.out.println("CityClassify Id : " + cca.getId() + "\nCityClassify Contact : "
//								+ cca.getContdet() + "\nCityClassify description : " + cca.getDescdetl());
//						break;
//					case 0:
//						System.exit(0);
//						break;
//					}
//				}
//			} else if (role == 2) {
//
//				System.out.println("1. USER DATA");
//				System.out.println("2. CITYCLASSIFIED DATA");
//				System.out.println("Enter your choice");
//				select = sc.nextInt();
//				if (select == 1) {
//					System.out.println("1 Insert User");
//					System.out.println("2 Update User");
//					System.out.println("3 Delete User");
//					System.out.println("4 View User");
//					System.out.println("5 View a User");
//					System.out.println("6 Enter city name to know what are the institution in that city");
//					System.out.println("7 Show City");
//					System.out.println("Enter 0 to exit");
//					sc = new Scanner(System.in);
//					System.out.println("Enter your choice");
//					ch = sc.nextInt();
//
//					switch (ch) {
//					case 0:
//						System.exit(0);
//						break;
//					case 1:
//						System.out.println("Enter UserId , Username , password");
//						userId = sc.nextInt();
//						sc.nextLine();
//						userName = sc.nextLine();
//						password = sc.nextLine();
//						user = new User(userId, userName, password);
//						result = userCtrl.insertUser(user);
//						if (result > 0) {
//							System.out.println("User inserted");
//						} else {
//							System.out.println("User Not insertd");
//						}
//						break;
//					case 2:
//						System.out.println("Enter UserId , Username , password");
//						userId = sc.nextInt();
//						sc.nextLine();
//						userName = sc.nextLine();
//						password = sc.nextLine();
//						user = new User(userId, userName, password);
//						result = userCtrl.insertUser(user);
//						if (result > 0) {
//							System.out.println("User Updated");
//						} else {
//							System.out.println("User Not Updated");
//						}
//						break;
//					case 3:
//						System.out.println("Enter UserId");
//						userId = sc.nextInt();
//						result = userCtrl.deleteUser(userId);
//						if (result > 0) {
//							System.out.println("User deleted");
//						} else {
//							System.out.println("User not deleted");
//						}
//						break;
//					case 4:
//						List<User> list = userCtrl.getAllUser();
//						for (User usr : list) {
//							System.out.println(usr.getUserId() + "\t" + usr.getName() + "\t" + usr.getPassword());
//						}
//						break;
//					case 5:
//						System.out.println("Enter UserId");
//						userId = sc.nextInt();
//						user = userCtrl.getUserById(userId);
//						System.out.println("UserId " + user.getUserId());
//						System.out.println("Username " + user.getName());
//						System.out.println("Password " + user.getPassword());
//						break;
//
//					case 6:
//						sc.nextLine();
//						System.out.println("Enter the city name");
//						String nameC = sc.nextLine();
//						List<City> list1 = userCtrl.getInstitutioByName(nameC);
//						for (City cty : list1) {
//							System.out.println(cty.getId() + "\t" + cty.getInst() + "\t" + cty.getInst_det());
//						}
//						break;
//					case 7:
//						System.out.println("Cities which are in list");
//						List<String> list2 = userCtrl.getallCities();
//						for (String cty : list2) {
//							System.out.println(cty);
//						}
//						break;
//
//					}
//				} else if (select == 2) {
//					System.out.println("1. Insert CityClassify");
//					System.out.println("2. Update CityClassify");
//					System.out.println("3. Delete CityClassify");
//					System.out.println("4. View CityClassify");
//					System.out.println("5. View a CityClassify");
//					System.out.println("Enter 0 to exit");
//					// Scanner sc = new Scanner(System.in);
//					System.out.println("Enter your choice");
//					ch = sc.nextInt();
//
//					switch (ch) {
//					case 1:
//						System.out.println("Enter Id, contact_no , description");
//						id = sc.nextInt();
//						sc.nextLine();
//						cno = sc.nextLine();
//						desc = sc.nextLine();
//						cca = new CityClassified(id, cno, desc);
//						result = ccc.insertCityClassify(cca);
//						if (result > 0) {
//							System.out.println("CityClassify inserted");
//						} else {
//							System.out.println("CityClassify not inserted");
//						}
//
//						break;
//
//					case 2:
//						System.out.println("Enter Id, contact_no , description");
//						id = sc.nextInt();
//						sc.nextLine();
//						cno = sc.nextLine();
//						desc = sc.nextLine();
//						cca = new CityClassified(id, cno, desc);
//						result = ccc.updateCityClassify(cca);
//						if (result > 0) {
//							System.out.println("CityClassify updated");
//						} else {
//							System.out.println("CityClassify not updated");
//						}
//						break;
//					case 3:
//						System.out.println("Enter CityClassifyid");
//						id = sc.nextInt();
//						result = ccc.deleteCityClassify(id);
//						if (result > 0) {
//							System.out.println("CityClassify Deleted");
//						} else {
//							System.out.println("CityClassify not deleted");
//						}
//
//						break;
//					case 4:
//						List<CityClassified> list = ccc.getAllCityClassify();
//						for (CityClassified admn : list) {
//							System.out.println("CityClassify Id : " + admn.getId() + "\n CityClassify Contact number : "
//									+ admn.getContdet() + "\n CityClassify description : " + admn.getDescdetl());
//						}
//
//						break;
//					case 5:
//
//						System.out.println("Enter CityClassify Id");
//						id = sc.nextInt();
//						cca = ccc.getAdminById(id);
//						System.out.println("CityClassify Id : " + cca.getId() + "\nCityClassify Contact : "
//								+ cca.getContdet() + "\nCityClassify description : " + cca.getDescdetl());
//						break;
//					case 0:
//						System.exit(0);
//						break;
//					}
//				}
//
//			} else {
//				System.out.println("CHOOSE A VALID OPTION");
//			}
//
//		}
//
//	}

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		System.out
//				.println("***WELCOME TO PROJECT***\n\n1 .User\n2 .Admin\n3 .City Classify Operation\nEnter an option");
//		Scanner sc = new Scanner(System.in);
//		int op = sc.nextInt();
//		int ch;
//		int uid;
//		String name;
//		String pswd;
//		int result;
//		UserController userCtrl = new UserController();
//		int aid;
//		String aName;
//		Admin admin = null;
//		AdminController adctrl = new AdminController();
//		CityController cityctrl = new CityController();
//		int id;
//		String cno;
//		String desc;
//		CityClassified cca = null;
//		CityClassifyController ccc = new CityClassifyController();
//
//		City city = null;
//
//		String cityname;
//		String inst;
//		String inst_det;
//		int choice;
//
//		User user = null;
//		if (op == 1) {
//			System.out.println("Welcome as a user\n\n");
//			while (true) {
//				System.out.println("1 Insert User");
//				System.out.println("2 Update User");
//				System.out.println("3 Delete User");
//				System.out.println("4 View User");
//				System.out.println("5 View a User");
//				System.out.println("6 Enter city name to know what are the institution in that city");
//				System.out.println("7 Show City");
//				System.out.println("Enter 0 to exit");
//				System.out.println("Enter your choice");
//				ch = sc.nextInt();
//
//				switch (ch) {
//				case 0:
//					System.exit(0);
//					break;
//				case 1:
//					System.out.println("Enter UserId , Username , password");
//					uid = sc.nextInt();
//					sc.nextLine();
//					name = sc.nextLine();
//					pswd = sc.nextLine();
//					user = new User(uid, name, pswd);
//					result = userCtrl.insertUser(user);
//					if (result > 0) {
//						System.out.println("User inserted");
//					} else {
//						System.out.println("User Not insertd");
//					}
//					break;
//				case 2:
//					System.out.println("Enter UserId , Username , password");
//					uid = sc.nextInt();
//					sc.nextLine();
//					name = sc.nextLine();
//					pswd = sc.nextLine();
//					user = new User(uid, name, pswd);
//					result = userCtrl.updateUser(user);
//					if (result > 0) {
//						System.out.println("User Updated");
//					} else {
//						System.out.println("User Not Updated");
//					}
//					break;
//				case 3:
//					System.out.println("Enter UserId");
//					uid = sc.nextInt();
//					result = userCtrl.deleteUser(uid);
//					if (result > 0) {
//						System.out.println("User deleted");
//					} else {
//						System.out.println("User not deleted");
//					}
//					break;
//				case 4:
//					List<User> list = userCtrl.getAllUser();
//					for (User usr : list) {
//						System.out.println(usr.getUserId() + "\t" + usr.getName() + "\t" + usr.getPassword());
//					}
//					break;
//				case 5:
//					System.out.println("Enter UserId");
//					uid = sc.nextInt();
//					user = userCtrl.getUserById(uid);
//					System.out.println("UserId " + user.getUserId());
//					System.out.println("Username " + user.getName());
//					System.out.println("Password " + user.getPassword());
//					break;
//				case 6:
//					sc.nextLine();
//					System.out.println("Enter the city name");
//					String nameC = sc.nextLine();
//					List<City> list1 = userCtrl.getInstitutioByName(nameC);
//					for (City cty : list1) {
//						System.out.println(cty.getId() + "\t" + cty.getInst() + "\t" + cty.getInst_det());
//					}
//					break;
//				case 7:
//					System.out.println("Cities which are in list");
//					List<String> list2 = userCtrl.getallCities();
//					for (String cty : list2) {
//						System.out.println(cty);
//					}
//					break;
//				}
//			}
//
//		} else if (op == 2) {
//			System.out.println("******Welcome as an Admin******\n\n");
//			System.out.println("1. Operate Admin\n2. Operate City\nEnter an option");
//			int op12 = sc.nextInt();
//			if (op12 == 1) {
//				while (true) {
//					System.out.println("1. Insert Admin");
//					System.out.println("2. Update Admin");
//					System.out.println("3. Delete Admin");
//					System.out.println("4. View Admin");
//					System.out.println("5. View a admin");
//					System.out.println("Enter 0 to exit");
//
//					System.out.println("Enter your choice");
//					ch = sc.nextInt();
//
//					switch (ch) {
//					case 1:
//						System.out.println("Enter AdminId, AdminName , password");
//						aid = sc.nextInt();
//						sc.nextLine();
//						aName = sc.nextLine();
//						pswd = sc.nextLine();
//						admin = new Admin(aid, aName, pswd);
//						result = adctrl.insertAdmin(admin);
//						if (result > 0) {
//							System.out.println("Admin inserted");
//						} else {
//							System.out.println("Admin not inserted");
//						}
//
//						break;
//
//					case 2:
//						System.out.println("Do You want to Oprate on City\n1.  yes\n2.  No");
//						int op2 = sc.nextInt();
//						if (op2 == 1) {
//
//						}
//						System.out.println("Enter AdminId, AdminName , password");
//						aid = sc.nextInt();
//						sc.nextLine();
//						aName = sc.nextLine();
//						pswd = sc.nextLine();
//						admin = new Admin(aid, aName, pswd);
//						result = adctrl.updateAdmin(admin);
//						if (result > 0) {
//							System.out.println("Admin updated");
//						} else {
//							System.out.println("Admin not updated");
//						}
//
//						break;
//					case 3:
//						System.out.println("Enter adminid");
//						aid = sc.nextInt();
//						result = adctrl.deleteAdmin(aid);
//						if (result > 0) {
//							System.out.println("Admin Deleted");
//						} else {
//							System.out.println("Admin not deleted");
//						}
//
//						break;
//					case 4:
//						List<Admin> list = adctrl.getAllAdmin();
//						for (Admin admn : list) {
//							System.out.println("Admin Id : " + admn.getAdminId() + "\n Admin Name : " + admn.getName()
//									+ "\n Admin Password : " + admn.getPassword());
//						}
//
//						break;
//					case 5:
//
//						System.out.println("Enter Admin Id");
//						aid = sc.nextInt();
//						admin = adctrl.getAdminById(aid);
//						System.out.println("Admin Id : " + admin.getAdminId() + "\nAdmin Name : " + admin.getName()
//								+ "\nAdmin Password : " + admin.getPassword());
//						break;
//					case 0:
//						System.exit(0);
//						break;
//					}
//				}
//			} else if (op12 == 2) {
//				while (true) {
//					System.out.println("1. Add City ");
//					System.out.println("2. Update City");
//					System.out.println("3. Delete City");
//					System.out.println("4. View Cities");
//					System.out.println("5. View a City");
//					System.out.println("6. institutions by city");
//					System.out.println("0. Exit ");
//					System.out.println("Enter your choice");
//					choice = sc.nextInt();
//
//					switch (choice) {
//					case 1:
//						System.out.println("Enter id,cityname,inst,inst_det");
//						id = sc.nextInt();
//						sc.nextLine();
//						cityname = sc.nextLine();
//						inst = sc.nextLine();
//						inst_det = sc.nextLine();
//						city = new City(id, cityname, inst, inst_det);
//						result = cityctrl.insertRecord(city);
//						if (result > 0)
//							System.out.println("Record Inserted");
//						else
//							System.out.println("Record not inserted");
//						break;
//
//					case 2:
//						System.out.println("Enter id,cityname,inst,inst_det");
//						id = sc.nextInt();
//						sc.nextLine();
//						cityname = sc.nextLine();
//						inst = sc.nextLine();
//						inst_det = sc.nextLine();
//						city = new City(id, cityname, inst, inst_det);
//						result = cityctrl.updateRecord(city);
//						if (result > 0)
//							System.out.println("Record updated");
//						else
//							System.out.println("Record not found");
//						break;
//
//					case 3:
//						System.out.println("Enter id");
//						id = sc.nextInt();
//						result = cityctrl.deleteRecord(id);
//						if (result > 0)
//							System.out.println("Record deleted");
//						else
//							System.out.println("Record not found");
//						break;
//
//					case 4:
//						List<City> list = cityctrl.getAllRecords();
//						for (City cit : list) {
//							System.out.println(cit.getId() + "\t" + cit.getCityname() + "\t" + cit.getInst() + "\t"
//									+ cit.getInst_det());
//						}
//						break;
//
//					case 5:
//						System.out.println("Enter id");
//						id = sc.nextInt();
//						city = cityctrl.getCityById(id);
//						System.out.println("Id = " + city.getId());
//						System.out.println("Cityname = " + city.getCityname());
//						System.out.println("Inst = " + city.getInst());
//						System.out.println("Inst = " + city.getInst_det());
//						break;
//
//					case 0:
//						System.exit(0);
//					}
//				}
//			}
//		} else if (op == 3) {
//			System.out.println("Welcome in City Classify\n\n");
//			while (true) {
//				System.out.println("1. Insert CityClassify");
//				System.out.println("2. Update CityClassify");
//				System.out.println("3. Delete CityClassify");
//				System.out.println("4. View CityClassify");
//				System.out.println("5. View a CityClassify");
//				System.out.println("Enter 0 to exit");
//				System.out.println("Enter your choice");
//				ch = sc.nextInt();
//
//				switch (ch) {
//				case 1:
//					System.out.println("Enter Id, contact_no , description");
//					id = sc.nextInt();
//					sc.nextLine();
//					cno = sc.nextLine();
//					desc = sc.nextLine();
//					cca = new CityClassified(id, cno, desc);
//					result = ccc.insertCityClassify(cca);
//					if (result > 0) {
//						System.out.println("CityClassify inserted");
//					} else {
//						System.out.println("CityClassify not inserted");
//					}
//
//					break;
//
//				case 2:
//					System.out.println("Enter Id, contact_no , description");
//					id = sc.nextInt();
//					sc.nextLine();
//					cno = sc.nextLine();
//					desc = sc.nextLine();
//					cca = new CityClassified(id, cno, desc);
//					result = ccc.updateCityClassify(cca);
//					if (result > 0) {
//						System.out.println("CityClassify updated");
//					} else {
//						System.out.println("CityClassify not updated");
//					}
//					break;
//				case 3:
//					System.out.println("Enter CityClassifyid");
//					id = sc.nextInt();
//					result = ccc.deleteCityClassify(id);
//					if (result > 0) {
//						System.out.println("CityClassify Deleted");
//					} else {
//						System.out.println("CityClassify not deleted");
//					}
//
//					break;
//				case 4:
//					List<CityClassified> list = ccc.getAllCityClassify();
//					for (CityClassified admn : list) {
//						System.out.println("CityClassify Id : " + admn.getId() + "\n CityClassify Contact number : "
//								+ admn.getContdet() + "\n CityClassify description : " + admn.getDescdetl());
//					}
//
//					break;
//				case 5:
//
//					System.out.println("Enter CityClassify Id");
//					id = sc.nextInt();
//					cca = ccc.getAdminById(id);
//					System.out.println("CityClassify Id : " + cca.getId() + "\nCityClassify Contact : "
//							+ cca.getContdet() + "\nCityClassify description : " + cca.getDescdetl());
//					break;
//				case 0:
//					System.exit(0);
//					break;
//				}
//			}
//
//		}
//
//	}
//case 2:
//	System.out.println("Enter Id, contact_no , description");
//	id = sc.nextInt();
//	sc.nextLine();
//	cno = sc.nextLine();
//	desc = sc.nextLine();
//	cca = new CityClassified(id, cno, desc);
//	result = ccc.updateCityClassify(cca);
//	if (result > 0) {
//		System.out.println("CityClassify updated");
//	} else {
//		System.out.println("CityClassify not updated");
//	}
//	break;
//case 3:
//	System.out.println("Enter CityClassifyid");
//	id = sc.nextInt();
//	result = ccc.deleteCityClassify(id);
//	if (result > 0) {
//		System.out.println("CityClassify Deleted");
//	} else {
//		System.out.println("CityClassify not deleted");
//	}
//
//	break;
//case 4:
//	List<CityClassified> list = ccc.getAllCityClassify();
//	for (CityClassified admn : list) {
//		System.out.println("CityClassify Id : " + admn.getId()
//				+ "\n CityClassify Contact number : " + admn.getContdet()
//				+ "\n CityClassify description : " + admn.getDescdetl());
//	}
//
//	break;
//case 5:
//
//	System.out.println("Enter CityClassify Id");
//	id = sc.nextInt();
//	cca = ccc.getAdminById(id);
//	System.out.println("CityClassify Id : " + cca.getId() + "\nCityClassify Contact : "
//			+ cca.getContdet() + "\nCityClassify description : " + cca.getDescdetl());
//	break;

}
