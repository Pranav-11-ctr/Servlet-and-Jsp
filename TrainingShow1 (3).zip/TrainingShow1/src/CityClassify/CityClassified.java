package CityClassify;

public class CityClassified {
	private int id;
//	private int userId;
//	private int aid;
	private String contdet;
	private String descdetl;
//	public int getUserId() {
//		return userId;
//	}
//	public void setUserId(int userId) {
//		this.userId = userId;
//	}
//	public int getAid() {
//		return aid;
//	}
//	public void setAid(int aid) {
//		this.aid = aid;
//	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContdet() {
		return contdet;
	}
	public void setContdet(String contdet) {
		this.contdet = contdet;
	}
	public String getDescdetl() {
		return descdetl;
	}
	
	public void setDescdetl(String descdetl) {
		this.descdetl = descdetl;
	}
	public CityClassified(int id, String contdet, String descdetl) {
		super();
		this.id = id;
		//this.userId = userId;
		this.contdet = contdet;
		this.descdetl = descdetl;
	}
//	public CityClassified( int aid, String contdet, String descdetl) {
//		super();
//		this.id = id;
//		//this.aid = aid;
//		this.contdet = contdet;
//		this.descdetl = descdetl;
//	}
	
	
	

}
