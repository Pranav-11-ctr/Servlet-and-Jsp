package CityClassify;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;





public class CityClassifyService implements CityClassifedCrud {

	public  int insertCityClassify(CityClassified ccf) {
		int result=0;
		try
		{
			Connection con =CityClassifyConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into cityclassified(id,contdet,descdetl) values(?,?,?)");
			ps.setInt(1, ccf.getId());
			ps.setString(2, ccf.getContdet());
			ps.setString(3,ccf.getDescdetl());
			
			result=ps.executeUpdate();
			con.close();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}


	public int updateCityClassify(CityClassified ccf) {
		int result=0;
		try
		{
			Connection con=CityClassifyConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("update cityclassified set contdet=?,descdetl=? where id=?");
			ps.setInt(3, ccf.getId());
			ps.setString(1,ccf.getContdet());
			ps.setString(2,ccf.getDescdetl());
			result=ps.executeUpdate();
			
			
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}


	public int deleteCityClassify(int ccfId) {
		int result=0;
		try
		{
			Connection con=CityClassifyConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from cityclassified where id=?");
			ps.setInt(1,ccfId);
			result=ps.executeUpdate();
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}


	public List<CityClassified> getAllCityClassify() {
		ArrayList<CityClassified> list=new ArrayList<>();
		int result=0;
		try
		{
			Connection con=CityClassifyConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet set=stmt.executeQuery("Select * from cityclassified");
			
			while(set.next())
			{
				list.add(new CityClassified(set.getInt(1),set.getString(2),set.getString(3)));
				
			}
			stmt.close();
			con.close();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;

	}

	@Override
	public CityClassified getCityClassifyById(int ccfId) {
		CityClassified ccf=null;
		try
		{
			Connection con=CityClassifyConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("Select * from cityclassified where id=?");
			ps.setInt(1,ccfId);
			ResultSet set=ps.executeQuery();
			if(set.next())
			{
				ccf=new CityClassified(set.getInt(1),set.getString(2),set.getString(3));
			}
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return ccf;	}

}
