package CityClassify;

import java.util.List;



public interface CityClassifedCrud {
	int insertCityClassify(CityClassified ccf);
	int updateCityClassify(CityClassified ccf);
	int deleteCityClassify(int ccfId);
	List<CityClassified> getAllCityClassify();
	CityClassified getCityClassifyById(int ccfId);
	

}
