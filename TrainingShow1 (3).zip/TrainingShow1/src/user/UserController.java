package user;

import java.util.List;

import city.City;
import newCityClassify.ncc;

public class UserController {
		UserService userService;
		
		public UserController()
		{
			userService=new UserService();
		}
		public List<City> getCities() {
			List<City> list=userService.getCities();
			return list;
		}
		
		public int insertUser(User user) {
			// TODO Auto-generated method stub
			int result=userService.insertUser(user);
			return result;
		}


		public int updateUser(User user) {
			// TODO Auto-generated method stub
			int result=userService.updateUser(user);
			return result;
		}

		public int deleteUser(int userId) {
			// TODO Auto-generated method stub
			int result=userService.deleteUser(userId);
			return result;
		}

		public List<User> getAllUser() {
			// TODO Auto-generated method stub
			List<User> list=userService.getAllUser();
			return list;
		}


		public User getUserById(int userId) {
			// TODO Auto-generated method stub
			User user=userService.getUserById(userId);
			return user;
		}	
		
		public List<ncc> getInstitutionByName(String name) 
		{
			List<ncc> list=userService.getInstitutionByName(name);
			return list;
		}
		
		public List<String> getallCities()
		{
			List<String> list=userService.getAllCities();
			return list;
		}
		public boolean checkCredential(int usid, String pswd1) {
			// TODO Auto-generated method stub
			boolean val=userService.checkCredential(usid, pswd1);
			return val;
		}

		

	}



