package user;

import java.util.List;
import newCityClassify.ncc;
import city.City;


public interface UserCrud {
	int insertUser(User user);
	int updateUser(User user);
	int deleteUser(int userId);
	List<User> getAllUser();
	User getUserById(int userId);
	List<ncc> getInstitutionByName(String name);
	List<String> getAllCities();
	List<City> getCities();
	boolean checkCredential(int usid,String pswd1);

}
