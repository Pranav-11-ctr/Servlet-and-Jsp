package user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import city.City;
import newCityClassify.ncc;





public class UserService implements UserCrud {

	@Override
	public int insertUser(User user)  {
		int result=0;
		try {
		Connection con=UserConnection.getConnection();
		 
			PreparedStatement ps=con.prepareStatement("insert into userDetails(userId,userName,password) values(?,?,?)");
			ps.setInt(1,user.getUserId());
			ps.setString(2,user.getName());
			ps.setString(3,user.getPassword());
			result=ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return result;
	}

	@Override
	public int updateUser(User user) {
		int result=0;
		try
		{
			Connection con=UserConnection.getConnection();
			//update studentDetails set studname=?,dob=? where rollno=? 
			PreparedStatement ps=con.prepareStatement("update userDetails set userName=?,password=? where userId=?");
			ps.setInt(3, user.getUserId());
			ps.setString(1,user.getName());
			ps.setString(2,user.getPassword());
			result=ps.executeUpdate();
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public int deleteUser(int userId) {
		int result=0;
		try
		{
			Connection con=UserConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from userDetails where userId=?");
			ps.setInt(1,userId);
			result=ps.executeUpdate();
		    con.close();
//			Connection con1=UserConnection.getConnection();
//			PreparedStatement ps1=con.prepareStatement("delete from cityclassified where used=?");
//			ps.setInt(1,userId);
//			result=ps1.executeUpdate();
//			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public List<User> getAllUser() {
		ArrayList<User> list=new ArrayList<>();
		try
		{
			Connection con=UserConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet set=stmt.executeQuery("Select * from userDetails");
			
			while(set.next())
			{
				list.add(new User(set.getInt(1),set.getString(2),set.getString(3)));
				
			}
			stmt.close();
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public User getUserById(int userId) {
		User user=null;
		try
		{
			Connection con=UserConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("Select * from userDetails where userId=?");
			ps.setInt(1,userId);
			ResultSet set=ps.executeQuery();
			if(set.next())
			{
				user=new User(set.getInt(1),set.getString(2),set.getString(3));
			}
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public List<ncc> getInstitutionByName(String name) {
		ArrayList<ncc> list=new ArrayList<>();
		try
		{
			Connection con=UserConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("Select id,contdet,descdetl from cityclassified where id=(select id from city where cityname=?)");
			ps.setString(1, name);
			ResultSet set=ps.executeQuery();
			while(set.next())
			{
				list.add(new ncc(set.getInt(1),set.getString(2),set.getString(3)));
				
			}
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public List<String> getAllCities() {
		ArrayList<String> list=new ArrayList<>();
		try
		{
			Connection con=UserConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet set=stmt.executeQuery("Select cityname from city");
			
			while(set.next())
			{
				list.add(set.getString(1));
				
			}
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;	}

	@Override
	public boolean checkCredential(int usid, String pswd1) {
		// TODO Auto-generated method stub
		ArrayList<UserLogin> list=new ArrayList<>();
		try {

			Connection con=UserConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet set=stmt.executeQuery("Select userId,password from userDetails");
			while(set.next())
			{
				list.add(new UserLogin(set.getInt(1),set.getString(2)));
			}
			con.close();
			for(int i=0;i<list.size();i++)
			{
				if(list.get(i).getUserId()==usid)
				{
					if(list.get(i).getPassword().equals(pswd1))
					{
						return true;
					}
				}
			}
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return false;
	}

	@Override
	public List<City> getCities() {
		// TODO Auto-generated method stub
		
		ArrayList<City> list=new ArrayList<>();
		try {

			Connection con=UserConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet set=stmt.executeQuery("Select id,cityname from city");
			while(set.next())
			{
				list.add(new City(set.getInt(1),set.getString(2)));
			}
//			stmt.close();
			con.close();
			
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return list;
	}

	

	

}
