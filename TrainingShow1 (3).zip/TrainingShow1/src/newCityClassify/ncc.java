package newCityClassify;

public class ncc {
	private int id;
	private int useId;
	private String contdet;
	private String descdetl;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUseId() {
		return useId;
	}
	public void setUseId(int useId) {
		this.useId = useId;
	}
	public String getContdet() {
		return contdet;
	}
	public void setContdet(String contdet) {
		this.contdet = contdet;
	}
	public String getDescdetl() {
		return descdetl;
	}
	public void setDescdetl(String descdetl) {
		this.descdetl = descdetl;
	}
	
	
	public ncc(int id, String contdet, String descdetl) {
		super();
		this.id = id;
		this.contdet = contdet;
		this.descdetl = descdetl;
	}
	public ncc(int id, int useId, String contdet, String descdetl) {
		super();
		this.id = id;
		this.useId = useId;
		this.contdet = contdet;
		this.descdetl = descdetl;
	}
	
	
	

}
