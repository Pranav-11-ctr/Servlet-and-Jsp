package newCityClassify;

import java.util.List;

import CityClassify.CityClassified;

public class nccController {
	nccService nserv;
	
	public nccController()
	{
		nserv=new nccService();
	}
	public int insertCityClassifyUser(ncc ccf) {
		// TODO Auto-generated method stub
		int result=nserv.insertCityClassifyUser(ccf);
		return result;
	}

	
//	public int insertCityClassifyAdmin(ncc ccf) {
//		// TODO Auto-generated method stub
//		int result=nserv.insertCityClassifyAdmin(ccf);
//		return result;
//	}

	
	public int updateCityClassify(ncc ccf) {
		// TODO Auto-generated method stub
		int result=nserv.updateCityClassify(ccf);
		return result;
	}


	public int deleteCityClassify(int ccfId) {
		// TODO Auto-generated method stub
		int result=nserv.deleteCityClassify(ccfId);
		return result;
	}

	public List<ncc> getAllCityClassify() {
		// TODO Auto-generated method stub
		List<ncc> list=nserv.getAllCityClassify();
		return list;
		
	}

	public ncc getCityClassifyByCityId(int ccfId) {
		// TODO Auto-generated method stub
		ncc nc1=nserv.getCityClassifyByCityId(ccfId);
		return nc1;
		
	}
	public List<ncc> getCityClassifyByUserId(int ccfId)
	{
		List<ncc> list=nserv.getCityClassifyByUserId(ccfId);
		return list;
	}
	public List<ncc> getCityClassifyUsers(int ccfId)
	{
		List<ncc> list=nserv.getCityClassifyUsers(ccfId);
		return list;
	}
	public int deleteCityByUserId(int useId)
	{
		int result=nserv.deleteCityByUserId(useId);
		return result;
	}
	


}
