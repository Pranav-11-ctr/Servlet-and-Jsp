package newCityClassify;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import CityClassify.CityClassified;
import CityClassify.CityClassifyConnection;
import city.City;
import user.UserConnection;

public class nccService implements nccCrud{

	@Override
	public int insertCityClassifyUser(ncc ccf) {
		// TODO Auto-generated method stub
		int result=0;
		try
		{
			Connection con =CityClassifyConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into cityclassified(id,useId,contdet,descdetl) values(?,?,?,?)");
			ps.setInt(1, ccf.getId());
			ps.setInt(2, ccf.getUseId());
			ps.setString(3, ccf.getContdet());
			ps.setString(4,ccf.getDescdetl());
			
			
			result=ps.executeUpdate();
			con.close();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}

//	@Override
//	public int insertCityClassifyAdmin(ncc ccf) {
//		// TODO Auto-generated method stub
//		int result=0;
//		try
//		{
//			Connection con =CityClassifyConnection.getConnection();
//			PreparedStatement ps=con.prepareStatement("insert into cityclassified(id,contdet,descdetl,aid) values(?,?,?,?)");
//			ps.setInt(1, ccf.getId());
//			ps.setString(2, ccf.getContdet());
//			ps.setString(3,ccf.getDescdetl());
//			ps.setInt(4,ccf.getAid());
//			
//			result=ps.executeUpdate();
//			con.close();
//			
//		}catch(Exception e)
//		{
//			e.printStackTrace();
//		}
//		return result;
//	}

	@Override
	public int updateCityClassify(ncc ccf) {
		// TODO Auto-generated method stub
		int result=0;
		try
		{
			Connection con=CityClassifyConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("update cityclassified set contdet=?,descdetl=? where id=?");
			ps.setInt(3, ccf.getId());
			ps.setString(1,ccf.getContdet());
			ps.setString(2,ccf.getDescdetl());
			result=ps.executeUpdate();
			
			
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
		
	}

	@Override
	public int deleteCityClassify(int ccfId) {
		// TODO Auto-generated method stub
		int result=0;
		try
		{
			Connection con=CityClassifyConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from cityclassified where id=?");
			ps.setInt(1,ccfId);
			result=ps.executeUpdate();
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public List<ncc> getAllCityClassify() {
		// TODO Auto-generated method stub
		ArrayList<ncc> list=new ArrayList<>();
		try
		{
			Connection con=CityClassifyConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet set=stmt.executeQuery("Select id,contdet,descdetl from cityclassified");
			
			while(set.next())
			{
				list.add(new ncc(set.getInt(1),set.getString(2),set.getString(3)));
				
			}
			stmt.close();
			con.close();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
		
	}

	@Override
	public ncc getCityClassifyByCityId(int ccfId) {
		// TODO Auto-generated method stub
		ncc ccf=null;
		try
		{
			Connection con=CityClassifyConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("Select id,contdet,descdetl from cityclassified where id=?");
			ps.setInt(1,ccfId);
			ResultSet set=ps.executeQuery();
			if(set.next())
			{
				ccf=new ncc(set.getInt(1),set.getString(2),set.getString(3));
			}
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return ccf;
		
	}

	@Override
	public List<ncc> getCityClassifyByUserId(int ccfId) {
		// TODO Auto-generated method stub
		ArrayList<ncc> list=new ArrayList<>();
		try
		{
//			
			
			Connection con=UserConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("Select id,contdet,descdetl from cityclassified where useid=?");
			ps.setInt(1, ccfId);
			ResultSet set=ps.executeQuery();
			while(set.next())
			{
				list.add(new ncc(set.getInt(1),set.getString(2),set.getString(3)));
				
			}
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public List<ncc> getCityClassifyUsers(int ccfId) {
		// TODO Auto-generated method stub
		ArrayList<ncc> list=new ArrayList<>();
			try
		{
			Connection con=CityClassifyConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("Select id,contdet,descdetl from cityclassified where useid NOT IN(select useid from cityclassified where useid=?)");
			ps.setInt(1, ccfId);
			ResultSet set=ps.executeQuery();
			while(set.next())
			{
				list.add(new ncc(set.getInt(1),set.getString(2),set.getString(3)));
				
			}
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;

		
	}

	@Override
	public int deleteCityByUserId(int useId) {
		int result=0;
		try
		{
			Connection con=CityClassifyConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from cityclassified where useId=?");
			ps.setInt(1,useId);
			result=ps.executeUpdate();
			con.close();
		}catch(Exception e)
		{
			
		}
		return result;
	}

}
