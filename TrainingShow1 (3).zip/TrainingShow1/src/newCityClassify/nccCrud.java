package newCityClassify;

import java.util.List;



public interface nccCrud {
	int insertCityClassifyUser(ncc ccf);
//	int insertCityClassifyAdmin(ncc ccf);
	int updateCityClassify(ncc ccf);
	int deleteCityClassify(int ccfId);
	int deleteCityByUserId(int useId);
	List<ncc> getAllCityClassify();
	ncc getCityClassifyByCityId(int ccfId);
	List<ncc> getCityClassifyByUserId(int ccfId);
	List<ncc> getCityClassifyUsers(int ccfId);

}
