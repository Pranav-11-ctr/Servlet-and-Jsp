package city;

import java.util.List;

public class CityController {
CityService userservice;
	
	public CityController() {
		userservice=new CityService();
	}
	public List<String> instituteType() {
		// TODO Auto-generated method stub
		List<String> list=userservice.instituteType();
		return list;
	}

	public List<City> getCityByInstitudeName(String instType) {
		// TODO Auto-generated method stub
		List<City> list=userservice.getCityByInstitudeName( instType);
		return list;
	}


	public int insertRecord(City city) {
		int result=userservice.insertRecord(city);
		return result;
	}

	public int updateRecord(City city) {
		int result=userservice.updateRecord(city);
		return result;
	}

	public int deleteRecord(int id) {
		int result=userservice.deleteRecord(id);
		return result;
	}

	public List<City> getAllRecords() {
		List <City> list=userservice.getAllRecords();
		return list;
	}

	public City getCityById(int id) {
		City city=userservice.getCityByid(id);
		return city;
	}

}
