package city;

import java.util.List;

public interface CityCrud {
	int insertRecord(City city);
	int updateRecord(City city);
	int deleteRecord(int id);
	List<City> getAllRecords();
	City getCityByid(int id);
	List<String> instituteType();
	List<City> getCityByInstitudeName(String instType);

}
