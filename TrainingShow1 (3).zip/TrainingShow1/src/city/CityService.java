package city;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import user.UserConnection;

public class CityService implements CityCrud{

	@Override
	public int insertRecord(City city) {
		int result=0;
		try{
			Connection con=CityConnection.getConnection();
			//To insert records 
			PreparedStatement ps=con.prepareStatement("insert into city(id, cityname, inst,inst_det) values(?,?,?,?)");
			ps.setInt(1,city.getId());
			ps.setString(2,city.getCityname());
			ps.setString(3,city.getInst());
			ps.setString(4,city.getInst_det());
			result=ps.executeUpdate();
			con.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
			
		return result;
	}

	@Override
	public int updateRecord(City city) {
		int result=0;
		try{
			Connection con=CityConnection.getConnection();
		
			
			//To insert records 
			PreparedStatement ps=con.prepareStatement("update city set cityname=?,inst=?,inst_det=? where id=?");
			
			ps.setString(1,city.getCityname());
			ps.setString(2, city.getInst());
			ps.setString(3,city.getInst_det());
			ps.setInt(4,city.getId());
			result=ps.executeUpdate();
			con.close();
			
			}
			catch(Exception e){
				e.printStackTrace();
			}
		return result;
	}

	@Override
	public int deleteRecord(int id) {
		int result=0;
		try{
			Connection con=CityConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from city where id=?");
			
			ps.setInt(1,id);
			
			result=ps.executeUpdate();
			con.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
		return result;
	}


	@Override
	public List<City> getAllRecords() {
		
		ArrayList<City> list=new ArrayList<>();
		try{
		Connection con=CityConnection.getConnection();
		//To get all Records
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select * from city");
		//Add all Records in ArrayList		
						
		while(rs.next()) {
			
			list.add(new City(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4)));
			//Student student=new Student(rs.getInt(1),rs.getString(2),rs.getDate(3));
			//list.add(student);
					
		}
		stmt.close();
		con.close();
		
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public City getCityByid(int id) {
		
		City city=null;
		try{
			Connection con=CityConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("Select * from city where id=?");
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery(); 
			if(rs.next())
				city=new City(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
			
			con.close();
			}
			catch(Exception e){
				e.printStackTrace();
			}
		return city;
	}

	@Override
	public List<String> instituteType() {
		// TODO Auto-generated method stub
		ArrayList<String> list=new ArrayList<>();
		try
		{
			Connection con=UserConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet set=stmt.executeQuery("Select inst from city");
			
			while(set.next())
			{
				list.add(set.getString(1));
				
			}
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public List<City> getCityByInstitudeName(String instType) {
		ArrayList<City> list=new ArrayList<>();
		try
		{
			Connection con=UserConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("Select cityname,inst_det from city where inst=?");
			ps.setString(1, instType);
			ResultSet rs=ps.executeQuery(); 
			
			while(rs.next())
			{
				list.add(new City(rs.getString(1),rs.getString(2)));
				
			}
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}


}
