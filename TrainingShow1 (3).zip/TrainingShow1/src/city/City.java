package city;


	public class City {
		public City(int id, String cityname) {
			super();
			this.id = id;
			this.cityname = cityname;
		}
		private int id;
		private String cityname;
		private String inst;
		private String inst_det;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getCityname() {
			return cityname;
		}
		public void setCityname(String cityname) {
			this.cityname = cityname;
		}
		public String getInst() {
			return inst;
		}
		public void setInst(String inst) {
			this.inst = inst;
		}
		public String getInst_det() {
			return inst_det;
		}
		public void setInst_det(String inst_det) {
			this.inst_det = inst_det;
		}
		public City(int id, String cityname, String inst, String inst_det) {
			super();
			this.id = id;
			this.cityname = cityname;
			this.inst = inst;
			this.inst_det = inst_det;
		}
		public City(String cityname, String inst_det) {
			super();
			this.cityname = cityname;
			this.inst_det = inst_det;
		}
		
		


}
